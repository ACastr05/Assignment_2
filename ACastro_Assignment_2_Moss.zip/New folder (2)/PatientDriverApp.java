import java.util.Scanner;
 
/*
 * Class: CMSC203
 * Instructor: Grigory Grinberg
 * Description: PatientDriverApp - tests the Patient and Procedure classes
 * 				by reading in a patient's information and up to 3 medical
 * 				procedures, then displaying all the information back out.
 * Due: 6/29/2026
 * Platform/compiler: Eclipse / Java SE
 * I pledge that I have completed the programming
 * assignment independently. I have not copied the code
 * from a student or any source. I have not given my code
 * to any student.
 * Print your Name here: Alani Castro

 */
public class PatientDriverApp {
 
	public static void main(String[] args) {
 
		Scanner keyboard = new Scanner(System.in);
 
		
		System.out.println("The program was developed by a Student: <Name> <07/27/24>");
		System.out.println();
 
	
		System.out.println("=== Enter Patient Information ===");
 
		System.out.print("First Name: ");
		String firstName = keyboard.nextLine();
 
		System.out.print("Middle Name: ");
		String middleName = keyboard.nextLine();
 
		System.out.print("Last Name: ");
		String lastName = keyboard.nextLine();
 
		System.out.print("Street Address: ");
		String streetAddress = keyboard.nextLine();
 
		System.out.print("City: ");
		String city = keyboard.nextLine();
 
		System.out.print("State: ");
		String state = keyboard.nextLine();
 
		System.out.print("Zip Code: ");
		String zipCode = keyboard.nextLine();
 
		System.out.print("Phone Number: ");
		String phoneNumber = keyboard.nextLine();
 
		System.out.print("Emergency Contact Name: ");
		String emergencyContactName = keyboard.nextLine();
 
		System.out.print("Emergency Contact Phone: ");
		String emergencyContactPhone = keyboard.nextLine();
 
	
		Patient patient = new Patient(firstName, middleName, lastName,
				streetAddress, city, state, zipCode, phoneNumber,
				emergencyContactName, emergencyContactPhone);
 
	
		System.out.println();
		System.out.println("=== Patient Information Saved ===");
		System.out.println(patient.toString());
		System.out.println();
 
		
		Procedure[] procedures = new Procedure[3];
		int procedureCount = 0;
 
		for (int i = 1; i <= 3; i++) {
			System.out.print("Would you like to enter Procedure " + i + "? (yes/no): ");
			String response = keyboard.nextLine();
 
			if (!response.equalsIgnoreCase("yes")) {
				break;
			}
 
			System.out.println("=== Enter Procedure " + i + " Information ===");
 
			System.out.print("Procedure Name: ");
			String procedureName = keyboard.nextLine();
 
			System.out.print("Procedure Date (MM/DD/YYYY): ");
			String procedureDate = keyboard.nextLine();
 
			System.out.print("Practitioner Name: ");
			String practitionerName = keyboard.nextLine();
 
			System.out.print("Charges: ");
			double charges = keyboard.nextDouble();
			keyboard.nextLine(); 
 
		
			Procedure procedure = new Procedure(procedureName, procedureDate,
					practitionerName, charges);
 
			procedures[procedureCount] = procedure;
			procedureCount++;
 
			System.out.println();
			System.out.println("=== Procedure " + i + " Saved ===");
			System.out.println(procedure.toString());
			System.out.println();
		}
 
		
		System.out.println("=== Final Output ===");
		System.out.println(patient.toString());
		System.out.println();
 
		if (procedureCount == 0) {
			System.out.println("No procedures were entered for this patient.");
		} else {
			for (int i = 0; i < procedureCount; i++) {
				System.out.println("--- Procedure " + (i + 1) + " ---");
				System.out.println(procedures[i].toString());
				System.out.println();
			}
		}
 
		keyboard.close();
	}
}