/*
 * Class: CMSC203
 * Instructor: Grigory Grinberg
 * Description: Procedure class - stores information about a medical
 * 				procedure that has been performed on a patient.
 * Due: 6/29/2026
 * I pledge that I have completed the programming
 * assignment independently. I have not copied the code
 * from a student or any source. I have not given my code
 * to any student.
 * Print your Name here: Alani Castro
 */
 

public class Procedure {
 
	private String procedureName;
	private String procedureDate;
	private String practitionerName;
	private double charges;
 

	public Procedure() {
		this.procedureName = "";
		this.procedureDate = "";
		this.practitionerName = "";
		this.charges = 0.0;
	}
 

	public Procedure(String name, String date) {
		this.procedureName = name;
		this.procedureDate = date;
		this.practitionerName = "";
		this.charges = 0.0;
	}
 

	public Procedure(String name, String date, String practitioner, double charges) {
		this.procedureName = name;
		this.procedureDate = date;
		this.practitionerName = practitioner;
		this.charges = charges;
	}
 
	
	public String getProcedureName() {
		return procedureName;
	}
 
	
	public void setProcedureName(String procedureName) {
		this.procedureName = procedureName;
	}
 
	
	public String getProcedureDate() {
		return procedureDate;
	}
 
	
	public void setProcedureDate(String procedureDate) {
		this.procedureDate = procedureDate;
	}
 
	
	public String getPractitionerName() {
		return practitionerName;
	}
 
	
	public void setPractitionerName(String practitionerName) {
		this.practitionerName = practitionerName;
	}
 
	
	public double getCharges() {
		return charges;
	}
 
	
	public void setCharges(double charges) {
		this.charges = charges;
	}
 
	
	public String toString() {
		return "Procedure: " + procedureName + "\n"
				+ "Date: " + procedureDate + "\n"
				+ "Practitioner: " + practitionerName + "\n"
				+ "Charges: $" + charges;
	}
}
 