/*
 * Class: CMSC203
 * Instructor: Grigory Grinberg
 * Description: Patient class - stores personal, address, and emergency
 * 				contact information for a patient.
 * Due: 6/29/2026
 * I pledge that I have completed the programming
 * assignment independently. I have not copied the code
 * from a student or any source. I have not given my code
 * to any student.
 * Print your Name here: Alani castro
 */
 
/**
 * The Patient class represents a patient's personal information,
 * including their name, address, phone number, and emergency contact.
 */
public class Patient {
 
	
	private String firstName;
	private String middleName;
	private String lastName;
 
	
	private String streetAddress;
	private String city;
	private String state;
	private String zipCode;
 
	
	private String phoneNumber;
	private String emergencyContactName;
	private String emergencyContactPhone;
 
	/**
	 * No-arg constructor. Sets all fields to an empty String.
	 */
	public Patient() {
		this.firstName = "";
		this.middleName = "";
		this.lastName = "";
		this.streetAddress = "";
		this.city = "";
		this.state = "";
		this.zipCode = "";
		this.phoneNumber = "";
		this.emergencyContactName = "";
		this.emergencyContactPhone = "";
	}
 
	/**
	 * Parameterized constructor that initializes only the patient's
	 * first, middle, and last name. All other fields are set to an
	 * empty String.
	 * @param firstName the patient's first name
	 * @param middleName the patient's middle name
	 * @param lastName the patient's last name
	 */
	public Patient(String firstName, String middleName, String lastName) {
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.streetAddress = "";
		this.city = "";
		this.state = "";
		this.zipCode = "";
		this.phoneNumber = "";
		this.emergencyContactName = "";
		this.emergencyContactPhone = "";
	}
 
	/**
	 * Parameterized constructor that initializes all 10 attributes
	 * of the patient to the given values.
	 * @param firstName the patient's first name
	 * @param middleName the patient's middle name
	 * @param lastName the patient's last name
	 * @param streetAddress the patient's street address
	 * @param city the patient's city
	 * @param state the patient's state
	 * @param zipCode the patient's zip code
	 * @param phoneNumber the patient's phone number
	 * @param emergencyContactName the name of the patient's emergency contact
	 * @param emergencyContactPhone the phone number of the patient's emergency contact
	 */
	public Patient(String firstName, String middleName, String lastName,
			String streetAddress, String city, String state, String zipCode,
			String phoneNumber, String emergencyContactName, String emergencyContactPhone) {
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.streetAddress = streetAddress;
		this.city = city;
		this.state = state;
		this.zipCode = zipCode;
		this.phoneNumber = phoneNumber;
		this.emergencyContactName = emergencyContactName;
		this.emergencyContactPhone = emergencyContactPhone;
	}
 
	
	public String getFirstName() {
		return firstName;
	}
 
	
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
 

	public String getMiddleName() {
		return middleName;
	}
 
	
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
 
	
	public String getLastName() {
		return lastName;
	}
 
	
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
 
	
	public String getStreetAddress() {
		return streetAddress;
	}
 
	
	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}
 
	
	public String getCity() {
		return city;
	}
 
	
	public void setCity(String city) {
		this.city = city;
	}
 
	
	public String getState() {
		return state;
	}
 
	
	public void setState(String state) {
		this.state = state;
	}
 
	
	public String getZipCode() {
		return zipCode;
	}
 
	
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
 
	
	public String getPhoneNumber() {
		return phoneNumber;
	}
 
	
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
 
	
	public String getEmergencyContactName() {
		return emergencyContactName;
	}
 
	
	public void setEmergencyContactName(String emergencyContactName) {
		this.emergencyContactName = emergencyContactName;
	}
 
	
	public String getEmergencyContactPhone() {
		return emergencyContactPhone;
	}
 
	
	public void setEmergencyContactPhone(String emergencyContactPhone) {
		this.emergencyContactPhone = emergencyContactPhone;
	}
 
	
	public String buildFullName() {
		return firstName + " " + middleName + " " + lastName;
	}
 
	
	public String buildAddress() {
		return streetAddress + " " + city + " " + state + " " + zipCode;
	}
 
	
	public String buildEmergencyContact() {
		return emergencyContactName + " " + emergencyContactPhone;
	}
 
	
	public String toString() {
		return "Patient Name: " + buildFullName() + "\n"
				+ "Address: " + buildAddress() + "\n"
				+ "Phone Number: " + phoneNumber + "\n"
				+ "Emergency Contact: " + buildEmergencyContact();
	}
}